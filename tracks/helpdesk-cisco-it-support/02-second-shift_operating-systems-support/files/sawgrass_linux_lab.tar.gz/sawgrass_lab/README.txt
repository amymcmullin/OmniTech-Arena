Sawgrass Logistics -- Linux lab pack (use inside your Linux VM)
=================================================================
1. Copy sawgrass_linux_lab.tar.gz into your VM (shared folder, USB, or download it
   from the CTF in the VM's browser).
2. Extract it IN A TERMINAL so the permissions are kept:
       tar -xzvf sawgrass_linux_lab.tar.gz
       cd sawgrass_lab
3. Useful commands: ls -la, cat, less, grep, grep -c, wc -l, cut, sort, uniq -c,
   chmod, find, pwd, cd
Answer the CTF challenges marked [VM].
