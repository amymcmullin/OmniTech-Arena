#!/bin/bash
# fix_printer.sh -- restarts the print spooler check (training version)
if [ ! -x "$0" ]; then
  echo "This script is not marked executable. Fix its permissions and run it as ./fix_printer.sh"
  exit 1
fi
echo "Printer queue check complete."
echo "FLAG: $(echo 'dekcolnu-x-sulp-domhc' | rev)"
